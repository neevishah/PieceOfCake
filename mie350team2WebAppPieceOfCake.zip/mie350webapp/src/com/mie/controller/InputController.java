package com.mie.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.ListIterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.RecipeDao;
import com.mie.model.Recipe;
import com.mie.model.User;
import com.mie.util.DbUtil;

public class InputController extends HttpServlet {
	/**
	 * This class handles all insert/edit/list functions of the servlet.
	 * 
	 * These are variables that lead to the appropriate JSP pages. INSERT leads
	 * to the Add A Student page. EDIT leads to the Edit A Student page.
	 * LIST_STUDENT_PUBLIC leads to the public listing of students.
	 * LIST_STUDENT_ADMIN leads to the admin-only listing of students (for them
	 * to modify student information).
	 * 
	 */
	
	private RecipeDao dao;
	static String selected_temp;
	static String selected_price;
	static String selected_fat;
	static String selected_cal;
	static String selected_v;
	static String selected_gf;
	static String selected_timetomake;
	//static String selected_temp = "\"Warm\" OR \"Cold\"";
	
	public InputController() {
		super();
		dao = new RecipeDao();
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("test1");
		HttpSession session = request.getSession(true);

		/**
		 * This class retrieves the appropriate 'action' found on the JSP pages:
		 * 
		 * - delete will direct the servlet to let the user delete a student in
		 * the database. - insert will direct the servlet to let the user add a
		 * new student to the database. - edit will direct the servlet to let
		 * the user edit student information in the database. - listStudent will
		 * direct the servlet to the public listing of all students in the
		 * database. - listStudentAdmin will direct the servlet to the admin
		 * listing of all students in the database.
		 */
		//get the responses from the radio button inputs in the quiz, then set variables to be read later when showing results
		//temp
		String temperature = request.getParameter("tempbutton") ;
		selected_temp = (temperature.equals("warm")?"Warm":temperature.equals("cold")?"Cold":temperature.equals("any")?"%":"f");
		
		//price
		String price = request.getParameter("price");
		selected_price = (price.equals("10")?"10":price.equals("15")?"15":price.equals("20")?"20":price.equals("any")?"100000":"10000");
		
		//fat
		String fat = request.getParameter("fatbutton");
		selected_fat = (fat.equals("minf")?"10":fat.equals("lowf")?"20":fat.equals("any")?"100000":"10000");
		
		//calories
		String cal = request.getParameter("calbutton");
		selected_cal = (cal.equals("minc")?"100":cal.equals("lowc")?"200":cal.equals("any")?"10000":"10000");
		
		//gluten free
		String gf = request.getParameter("gfbutton");
		selected_gf = (gf.equals("y")?"True":gf.equals("n")?"False":gf.equals("any")?"False":"False");
		
		//vegan
		String v = request.getParameter("vbutton");
		selected_v = (v.equals("y2")?"True":v.equals("n2")?"False":v.equals("any")?"False":"False");
		
		//recipe time
		String timetomake = request.getParameter("minbutton");
		selected_timetomake = (timetomake.equals("30min")?"30":timetomake.equals("1hour")?"60":timetomake.equals("2hour")?"120":timetomake.equals("any")?"10000":"10000");
		
		request.setAttribute("recipes", dao.getResults());
		
		//go to quiz output page if all responses received
		RequestDispatcher view = request.getRequestDispatcher("quizOutput.jsp");
		view.forward(request, response);
			
	}
		
	//getters so orderReviewController can set values for the output
	public static String getTemp(){
		return selected_temp;
	}
	
	public static Double getPrice(){
		return Double.parseDouble(selected_price);
	}
	
	public static Double getFat(){
		return Double.parseDouble(selected_fat);
	}
	
	public static Double getCal(){
		return Double.parseDouble(selected_cal);
	}
	
	public static boolean getGF(){
		if (selected_gf == "True") {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static boolean getV(){
		if (selected_v == "True") {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static Double getTimeToMake(){
		return Double.parseDouble(selected_timetomake);
	}
	
}
	
