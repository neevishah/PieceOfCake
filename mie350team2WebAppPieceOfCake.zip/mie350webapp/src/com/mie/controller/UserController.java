package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.mie.dao.UserDao;
import com.mie.model.Recipe;
import com.mie.model.User;

public class UserController extends HttpServlet {
	/**
	 * This class handles all insert/edit/list functions of the servlet.
	 * 
	 * These are variables that lead to the appropriate JSP pages. INSERT leads
	 * to the Add A Student page. EDIT leads to the Edit A Student page.
	 * LIST_STUDENT_PUBLIC leads to the public listing of students.
	 * LIST_STUDENT_ADMIN leads to the admin-only listing of students (for them
	 * to modify student information).
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String INSERT = "/createaccount.jsp";
	private static String EDIT = "/editUser.jsp";
	private static String DELETE = "/deleteUser.jsp";
	private static String GO = "/index.jsp";
	private static String LOGGEDIN = "/user_loggedin.jsp";
	//private static String LIST_STUDENT_PUBLIC = "/listStudentPublic.jsp";
	//private static String LIST_STUDENT_ADMIN = "/listStudentAdmin.jsp";

	private UserDao dao;
	

	/**
	 * Constructor for this class.
	 */
	public UserController() {
		super();
		dao = new UserDao();
	}

	protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
		System.out.println("test1");
		
		User user = new User();
		user.setEmail(request.getParameter("em"));
		user.setPassword(request.getParameter("pw"));
		
		HttpSession session = request.getSession(true);
		user = UserDao.login(user);
		session.setAttribute("currentSessionmember", user);
		session.setAttribute("em", user.getEmail());
		session.setAttribute("fn", user.getFirstName());
		session.setAttribute("ln", user.getLastName());
		session.setAttribute("a", user.getAddress());
		session.setAttribute("c", user.getCity());

		/**
		 * This class retrieves the appropriate 'action' found on the JSP pages:
		 * 
		 * - delete will direct the servlet to let the user delete a student in
		 * the database. - insert will direct the servlet to let the user add a
		 * new student to the database. - edit will direct the servlet to let
		 * the user edit student information in the database. - listStudent will
		 * direct the servlet to the public listing of all students in the
		 * database. - listStudentAdmin will direct the servlet to the admin
		 * listing of all students in the database.
		 */
		String forward = "";
		String action = request.getParameter("action");
		
		if (action.equalsIgnoreCase("Delete")) {
			System.out.println("deleteworks");
			String Email = request.getParameter("email");
			System.out.println(Email);
			dao.deleteUser(Email);
			forward = GO;
		}
			//request.setAttribute("recipes", dao.getAllRecipes()); 
		else if (action.equalsIgnoreCase("submit")) {
			forward = INSERT;
		} else if (action.equalsIgnoreCase("edit")) {
			String Email = request.getParameter("email");
			User user1 = dao.getUserByEmail(Email);
			forward = EDIT;
			request.setAttribute("user", user1);
		}  else {
			forward = INSERT;
		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This method retrieves all of the information entered in the form on
		 * the addStudent.jsp or the editStudent.jsp pages.
		 */
		User user = new User();
		user.setEmail(request.getParameter("em"));
		user.setPassword(request.getParameter("pw"));
		user.setFirstName(request.getParameter("fn"));
		user.setLastName(request.getParameter("ln"));
		user.setCity(request.getParameter("c"));
		user.setAddress(request.getParameter("a"));
		//user.setRegionID(Integer.parseInt("r"));
		user.setCreditCardNum(request.getParameter("cc"));
		user.setCVC((request.getParameter(("cvc"))));
		user.setExpiration(request.getParameter("ex"));
		String email = request.getParameter("email");
		//user.setAccountId(Integer.parseInt("id"));
		
		HttpSession session = request.getSession(true);
		user = UserDao.login(user);
		session.setAttribute("currentSessionmember", user);
		session.setAttribute("em", user.getEmail());
		session.setAttribute("fn", user.getFirstName());
		session.setAttribute("ln", user.getLastName());

		
		/**
		 * If the 'email' field in the form is empty, the new student will
		 * be added to the list of user  objects.
		 */
		if (email == null || email.isEmpty()) {
			dao.addUser(user);
			
		} else {
			/**
			 * Otherwise, if the field is already filled (this occurs when the
			 * user is trying to Edit A Student), then the student's information
			 * will be updated accordingly.
			 */
			user.setEmail(email);
			dao.updateUser(user);
			//dao.deleteUser(email);
		}
		/**
		 * Once the student has been added or updated, the page will redirect to
		 * the listing of students.
		 */

		RequestDispatcher view = request
				.getRequestDispatcher(LOGGEDIN);
		//request.setAttribute("students", dao.getAllStudents());
		view.forward(request, response); 
	}
}