package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.RecipeDao;
import com.mie.dao.UserDao;
import com.mie.model.Recipe;
import com.mie.model.User;

public class RecipeController extends HttpServlet {
	/**
	 * This class handles all insert/edit/list functions of the servlet.
	 * 
	 * These are variables that lead to the appropriate JSP pages. INSERT leads
	 * to the Add A recipe page. EDIT leads to the Edit A recipe page.
	 * RECIPE_LIST_ADMIN leads to the admin-only listing of recipes (for them
	 * to modify recipe information).
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String RESULTS = "/quizOutput.jsp";
	private static String INSERT = "/addRecipe.jsp";
	private static String EDIT = "/editRecipe.jsp";
	private static String RECIPE_LIST_ADMIN = "/RecipeListAdmin.jsp";

	private RecipeDao dao;

	/**
	 * Constructor for this class.
	 */
	public RecipeController() {
		super();
		dao = new RecipeDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This class retrieves the appropriate 'action' found on the JSP pages:
		 * 
		 * - delete will direct the servlet to let the user delete a recipe in
		 * the database. - insert will direct the servlet to let the user add a
		 * new recipe to the database. - edit will direct the servlet to let
		 * the user edit recipe information in the database. - listrecipe will
		 * direct the servlet to the public listing of all recipes in the
		 * database. - recipelistAdmin will direct the servlet to the admin
		 * listing of all recipes in the database.
		 */
		
		String forward = "";
		String action = request.getParameter("action");
		
		//lets the admin delete/insert/edit recipes
		if (action.equalsIgnoreCase("delete")) {
			int recipeid = Integer.parseInt(request.getParameter("RecipeID"));
			dao.deleteRecipe(recipeid);
			forward = RECIPE_LIST_ADMIN;
			request.setAttribute("recipes", dao.getAllRecipes());
		} else if (action.equalsIgnoreCase("insert")) {
			forward = INSERT;
		} else if (action.equalsIgnoreCase("edit")) {
			int recipeid = Integer.parseInt(request.getParameter("RecipeID"));
			Recipe recipe1 = dao.getRecipeById(recipeid);
			forward = EDIT;
			request.setAttribute("recipe", recipe1);
		} else if (action.equalsIgnoreCase("RecipeListAdmin")) {
			forward = RECIPE_LIST_ADMIN;
			request.setAttribute("recipes", dao.getAllRecipes());
		} else {
			forward = INSERT;
		}
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}	
		
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This method retrieves all of the information entered in the form on
		 * the addrecipe.jsp or the editrecipe.jsp pages.
		 */
		
		Recipe recipe = new Recipe();
		recipe.setRecipeName(request.getParameter("recipename"));
		recipe.setRecipe(request.getParameter("recipe"));		
		recipe.setPrice(Double.parseDouble(request.getParameter("price")));
		recipe.setCalories(Double.parseDouble(request.getParameter("calories")));
		recipe.setFat(Double.parseDouble(request.getParameter("fat")));
		recipe.setVegan(Boolean.parseBoolean(request.getParameter("vegan")));
		recipe.setGlutenFree(Boolean.parseBoolean(request.getParameter("glutenfree")));
		recipe.setTemperature(request.getParameter("temperature"));
		recipe.setTimeToMake(Double.parseDouble(request.getParameter("timetomake")));
		recipe.setAvailable(Boolean.parseBoolean(request.getParameter("available")));
		
		String recipeid = request.getParameter("recipeid");
		
		/**
		 * If the 'recipeid' field in the form is empty, the new recipe will
		 * be added to the list of recipe objects.
		 */
		
		if (recipeid == null || recipeid.isEmpty()) {
			dao.addRecipe(recipe);
		} else {
			/**
			 * Otherwise, if the field is already filled (this occurs when the
			 * user is trying to Edit A Recipe), then the recipe's information
			 * will be updated accordingly.
			 */
			recipe.setRecipeId(Integer.parseInt(recipeid));
			dao.updateRecipe(recipe);
		}
		/**
		 * Once the recipe has been added or updated, the page will redirect to
		 * the listing of recipes.
		 */
		RequestDispatcher view = request
				.getRequestDispatcher(RECIPE_LIST_ADMIN);
		request.setAttribute("recipes", dao.getAllRecipes());
		view.forward(request, response);
		
	}
}