package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.RecipeDao;
import com.mie.model.Recipe;

public class OrderReviewController extends HttpServlet {
	
	private RecipeDao dao;
	
	public OrderReviewController() {
		super();
		dao = new RecipeDao();
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Recipe recipePick = new Recipe();
		
		//get the recipeID the user submitted from the quiz output
		HttpSession session = request.getSession(true);
		int recipeID = Integer.parseInt(request.getParameter("recipeID"));
		
		request.setAttribute("recipePick", dao.getRecipeById(recipeID));
		
		//go to the order review page
		RequestDispatcher view = request.getRequestDispatcher("order.jsp");
		view.forward(request, response);
	}

}
