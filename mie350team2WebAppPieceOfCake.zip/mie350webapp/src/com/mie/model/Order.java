package com.mie.model;
public class Order {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Student object.
	 */

	private int orderid;
	private int accountid;
	private int recipeid;
	private int deliveryid;
	
	public int getRecipeId() {
		return recipeid;
	}

	public void setRecipeId(int recipeid) {
		this.recipeid = recipeid;
	}

	public int getOrderId() {
		return orderid;
	}

	public void setOrderId(int orderid) {
		this.orderid = orderid;
	}
	
	public int getAccountId() {
		return accountid;
	}

	public void setAccountId(int accountid) {
		this.accountid = accountid;
	}

	public int getDeliveryId() {
		return deliveryid;
	}

	public void setDeliveryId(int deliveryid) {
		this.deliveryid = deliveryid;
	}
}