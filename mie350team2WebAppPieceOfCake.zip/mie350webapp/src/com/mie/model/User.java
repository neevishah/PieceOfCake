package com.mie.model;

import java.util.Date;

public class User {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Student object.
	 */

	
	private int accountid;
	private String firstName;
	private String lastName;
	private String expiration;
	private String email;
	private String address;
	private int regionid;
	private String city;
	private String cardnum;
	private String cvc;
	private String password;
	private boolean valid;
	

	public int getAccountId() {
		return accountid;
	}

	public void setAccountId(int accountid) {
		this.accountid = accountid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	public String getCreditCardNum() {
		return cardnum;
	}

	public void setCreditCardNum(String cardnum) {
		this.cardnum = cardnum;
	}
	public int getRegionID() {
		return regionid;
	}

	public void setRegionID(int regionid) {
		this.regionid = regionid;
	}
	
	public String getCVC() {
		return cvc;
	}

	public void setCVC(String cvc) {
		this.cvc = cvc;
	}
	
	public String getPassword(){
		return password;
	}
	
	public void setPassword(String password){
		this.password=password;
		
		
	}
	
	public String getExpiration() {
		return expiration;
	}

	public void setExpiration(String expiration) {
		this.expiration = expiration;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "User [AccountID=" + accountid + ", FirstName=" + firstName
				+ ", LastName=" + lastName + ", Address=" + address + ", City=" + city + ", RegionID=" + regionid + ", CreditCardNumber=" + cardnum +  ", CVC=" + cvc + ", Password= " + password + ", Expiration=" + expiration + ", Email=" + email +"]";
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean newValid) {
		valid = newValid;
	}

}