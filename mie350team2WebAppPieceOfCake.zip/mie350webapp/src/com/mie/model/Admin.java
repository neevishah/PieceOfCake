package com.mie.model;

import java.util.Date;

public class Admin {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Member object.
	 */
	private int adminid;
	private String firstName;
	private String lastName;
	private String password;
	private String email;
	private boolean valid;

	public int getAdminId() {
		return adminid;
	}

	public void setAdminId(int adminid) {
		this.adminid = adminid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean newValid) {
		valid = newValid;
	}

	@Override
	public String toString() {
		return "Admin [AdminId=" + adminid + ", FirstName=" + firstName
				+ ", LastName=" + lastName + ", Password=" + password +
				", Email=" + email + "]";
	}
}