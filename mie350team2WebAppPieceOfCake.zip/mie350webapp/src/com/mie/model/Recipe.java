package com.mie.model;

import java.util.Date;

public class Recipe {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Student object.
	 */

	private int recipeid;
	private String recipename;
	private String recipe;
	private double price;
	private double calories;
	private double fat;
	private boolean vegan;
	private boolean glutenfree;
	private String temperature;
	private double timetomake;
	private boolean available;

	public int getRecipeId() {
		return recipeid;
	}

	public void setRecipeId(int recipeid) {
		this.recipeid = recipeid;
	}

	public String getRecipeName() {
		return recipename;
	}

	public void setRecipeName(String recipename) {
		this.recipename = recipename;
	}

	public String getRecipe() {
		return recipe;
	}

	public void setRecipe(String recipe) {
		this.recipe = recipe;
	}

	public double getPrice(){
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public double getCalories(){
		return calories;
	}

	public void setCalories(double calories) {
		this.calories = calories;
	}

	public double getFat() {
		return fat;
	}

	public void setFat(double fat) {
		this.fat = fat;
	}
	
	public boolean getVegan() {
		return vegan;
	}

	public void setVegan(boolean vegan) {
		this.vegan = vegan;
	}
	
	public boolean getGlutenFree(){
		return glutenfree;
	}

	public void setGlutenFree(boolean glutenfree) {
		this.glutenfree = glutenfree;
	}
	
	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}
	
	public double getTimeToMake() {
		return timetomake;
	}

	public void setTimeToMake(double timetomake) {
		this.timetomake = timetomake;
	}
	
	public boolean getAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}
	

	@Override
	public String toString() {
		return "Recipe [RecipeId=" + recipeid + ", RecipeName=" + recipename
				+ ", Recipe=" + recipe + ", Price=" + price + ", Calories="
				+ calories + ", Fat=" + fat + ", Vegan=" + vegan + ", GlutenFree=" 
				+ glutenfree + ", Temperature=" + temperature + ", TimeToMake=" + 
				timetomake + ", Available=" + available + "]";
		
	}
}