package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.controller.InputController;
import com.mie.model.Recipe;
import com.mie.util.DbUtil;

public class RecipeDao {
	/**
	 * This class handles all of the Student-related methods
	 * (add/update/delete/get).
	 */

	private Connection connection;

	public RecipeDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}

	public void addRecipe(Recipe recipe) {
		/**
		 * This method adds a new student to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into Recipe(recipeid, recipename, recipe, price, calories, fat, vegan, glutenfree, temperature, timetomake, available) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			// Parameters start with 1
			preparedStatement.setInt(1, recipe.getRecipeId());
			preparedStatement.setString(2, recipe.getRecipeName());
			preparedStatement.setString(3, recipe.getRecipe());
			preparedStatement.setDouble(4, recipe.getPrice());
			preparedStatement.setDouble(5, recipe.getCalories());
			preparedStatement.setDouble(6, recipe.getFat());
			preparedStatement.setBoolean(7, recipe.getVegan());
			preparedStatement.setBoolean(8, recipe.getGlutenFree());
			preparedStatement.setString(9, recipe.getTemperature());
			preparedStatement.setDouble(10, recipe.getTimeToMake());
			preparedStatement.setBoolean(11, recipe.getAvailable());
			
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteRecipe(int recipeid) {
		/**
		 * This method deletes a recipe from the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from Recipe where RecipeID=?");
			// Parameters start with 1
			preparedStatement.setInt(1, recipeid);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateRecipe (Recipe recipe) {
		/**
		 * This method updates a student's information into the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("update Recipe set RecipeName=?, Recipe=?, Price=?, Calories=?, Fat=?, Vegan=?, GlutenFree=?, Temperature=?, TimeToMake=?, Available=?  where RecipeID=?");
			// Parameters start with 1
			
			preparedStatement.setString(1, recipe.getRecipeName());
			preparedStatement.setString(2, recipe.getRecipe());
			preparedStatement.setDouble(3, recipe.getPrice());
			preparedStatement.setDouble(4, recipe.getCalories());
			preparedStatement.setDouble(5, recipe.getFat());
			preparedStatement.setBoolean(6, recipe.getVegan());
			preparedStatement.setBoolean(7, recipe.getGlutenFree());
			preparedStatement.setString(8, recipe.getTemperature());
			preparedStatement.setDouble(9, recipe.getTimeToMake());
			preparedStatement.setBoolean(10, recipe.getAvailable());
			preparedStatement.setInt(11, recipe.getRecipeId());
			
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Object getAllRecipes() {

		List<Recipe> recipes = new ArrayList<Recipe>();
		
		
		try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from Recipe");
			while (rs.next()) {
				Recipe recipe1 = new Recipe();
				recipe1.setRecipeId(rs.getInt("recipeid"));
				recipe1.setRecipeName(rs.getString("recipename"));
				recipe1.setRecipe(rs.getString("recipe"));
				recipe1.setPrice(rs.getDouble("price"));
				recipe1.setCalories(rs.getDouble("calories"));
				recipe1.setFat(rs.getDouble("fat"));
				recipe1.setVegan(rs.getBoolean("vegan"));
				recipe1.setGlutenFree(rs.getBoolean("glutenfree"));
				recipe1.setTemperature(rs.getString("temperature"));
				recipe1.setTimeToMake(rs.getDouble("timetomake"));
				recipe1.setAvailable(rs.getBoolean("available"));
				
				recipes.add(recipe1);
		
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return recipes;
	}

	public Recipe getRecipeById(String recipeID) {
		Recipe recipe = new Recipe();
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Recipe where RecipeID=?");
			preparedStatement.setString(1, recipeID);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				recipe.setRecipeName(rs.getString("recipename"));
				recipe.setRecipe(rs.getString("recipe"));
				recipe.setPrice(rs.getDouble("price"));
				recipe.setCalories(rs.getDouble("calories"));
				recipe.setFat(rs.getDouble("fat"));
				recipe.setVegan(rs.getBoolean("vegan"));
				recipe.setGlutenFree(rs.getBoolean("glutenfree"));
				recipe.setTemperature(rs.getString("temperature"));
				recipe.setTimeToMake(rs.getDouble("timetomake"));
				recipe.setAvailable(rs.getBoolean("available"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return recipe;
	}
	

	
	public Recipe getRecipeById(int recipeID) {
		Recipe recipe = new Recipe();
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Recipe where RecipeID=?");
			preparedStatement.setInt(1, recipeID);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				recipe.setRecipeId(recipeID);
				recipe.setRecipeName(rs.getString("recipename"));
				recipe.setRecipe(rs.getString("recipe"));
				recipe.setPrice(rs.getDouble("price"));
				recipe.setCalories(rs.getDouble("calories"));
				recipe.setFat(rs.getDouble("fat"));
				recipe.setVegan(rs.getBoolean("vegan"));
				recipe.setGlutenFree(rs.getBoolean("glutenfree"));
				recipe.setTemperature(rs.getString("temperature"));
				recipe.setTimeToMake(rs.getDouble("timetomake"));
				recipe.setAvailable(rs.getBoolean("available"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return recipe;
	}
	
	public Object getResults() {
		
		List<Recipe> recipes = new ArrayList<Recipe>();
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Recipe where Temperature LIKE ? AND Price < ? AND Fat <= ? AND Calories <=? AND Vegan=? AND GlutenFree =? AND TimeToMake <=? AND Available = ?");
			
			/*if (InputController.getTemp().equals("Warm OR Cold")) { 
				PreparedStatement preparedStatement = connection
						.prepareStatement("select * from Recipe where Temperature = Warm AND Temperature = Cold");
			}*/
		
			preparedStatement.setString(1, InputController.getTemp());
			preparedStatement.setDouble(2, InputController.getPrice());
			preparedStatement.setDouble(3, InputController.getFat());
			preparedStatement.setDouble(4, InputController.getCal());
			preparedStatement.setBoolean(5, InputController.getV());
			preparedStatement.setBoolean(6, InputController.getGF());
			preparedStatement.setDouble(7, InputController.getTimeToMake());
			preparedStatement.setBoolean(8, true);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				Recipe recipe1 = new Recipe();
				recipe1.setRecipeId(rs.getInt("recipeid"));
				recipe1.setRecipeName(rs.getString("recipename"));
				recipe1.setRecipe(rs.getString("recipe"));
				recipe1.setPrice(rs.getDouble("price"));
				recipe1.setCalories(rs.getDouble("calories"));
				recipe1.setFat(rs.getDouble("fat"));
				recipe1.setVegan(rs.getBoolean("vegan"));
				recipe1.setGlutenFree(rs.getBoolean("glutenfree"));
				recipe1.setTemperature(rs.getString("temperature"));
				recipe1.setTimeToMake(rs.getDouble("timetomake"));
				recipe1.setAvailable(rs.getBoolean("available"));
				
				recipes.add(recipe1);

		}
			
		}
			catch (SQLException e) {
			e.printStackTrace();
		}
		return recipes;
	}
		
		
		
//		// double price = 0.0;
//				if (q != null && q.equals("$0-$5")){
//					try {
//						PreparedStatement preparedStatement = connection.prepareStatement("select * from Recipe where Price<=5");
//						preparedStatement.setString(1, q);
//					}catch (SQLException e) {
//						e.printStackTrace();
//					}
//				}
//				else if (q != null && q.equals("$5-$10")){
//					try {
//						PreparedStatement preparedStatement = connection.prepareStatement("select * from Recipe where Price<=10 && Price>=5");
//						preparedStatement.setString(1, q);
//					}catch (SQLException e) {
//						e.printStackTrace();
//					}
//				}
//				else if (q != null && q.equals("$10-$15")){
//					try {
//						PreparedStatement preparedStatement = connection.prepareStatement("select * from Recipe where Price<=15 && price>=10");
//						preparedStatement.setString(1, q);
//					}catch (SQLException e) {
//						e.printStackTrace();
//					}
//				}
			
			
	
	// MIGHT BE HELPFUL FOR FILTER 

//	public List<Student> getStudentByKeyword(String keyword) {
//		/**
//		 * This method retrieves a list of students that matches the keyword
//		 * entered by the user.
//		 */
//		List<Student> students = new ArrayList<Student>();
//		try {
//			PreparedStatement preparedStatement = connection
//					.prepareStatement("select * from students where firstname LIKE ? OR lastname LIKE ? OR email LIKE ? OR dob LIKE ?");
//
//			preparedStatement.setString(1, "%" + keyword + "%");
//			preparedStatement.setString(2, "%" + keyword + "%");
//			preparedStatement.setString(3, "%" + keyword + "%");
//			preparedStatement.setString(4, "%" + keyword + "%");
//			ResultSet rs = preparedStatement.executeQuery();
//			while (rs.next()) {
//				Student student = new Student();
//				student.setStudentid(rs.getInt("studentid"));
//				student.setFirstName(rs.getString("firstname"));
//				student.setLastName(rs.getString("lastname"));
//				student.setDob(rs.getDate("dob"));
//				student.setEmail(rs.getString("email"));
//				students.add(student);
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//
//		return students;
//	}

}