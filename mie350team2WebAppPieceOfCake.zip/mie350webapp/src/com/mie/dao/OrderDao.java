package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.controller.InputController;
import com.mie.model.Order;
import com.mie.util.DbUtil;

public class OrderDao {
	/**
	 * This class handles all of the Student-related methods
	 * (add/update/delete/get).
	 */

	private Connection connection;

	public OrderDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}

	public void addOrder(Order order) {
		/**
		 * This method adds a new student to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into Orders(orderid, recipeid, accountid, deliveryid) values (?, ?, ?, ?)");
			// Parameters start with 1
			preparedStatement.setInt(1, order.getOrderId());
			preparedStatement.setInt(2, order.getRecipeId());
			preparedStatement.setInt(3, order.getAccountId());
			preparedStatement.setInt(4, order.getDeliveryId());
			
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Order getOrderById(String orderID) {
		Order order = new Order();
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Orders where OrderID=?");
			preparedStatement.setString(1, orderID);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				order.setRecipeId((rs.getInt("recipeid")));
				order.setAccountId(rs.getInt("accountid"));
				order.setDeliveryId(rs.getInt("deliveryid"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return order;
	}
	

	
	public Order getOrderById(int orderID) {
		Order order = new Order();
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Recipe where RecipeID=?");
			preparedStatement.setInt(1, orderID);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				order.setRecipeId((rs.getInt("recipeid")));
				order.setAccountId(rs.getInt("accountid"));
				order.setDeliveryId(rs.getInt("deliveryid"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return order;
	}
}