package com.mie.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.model.User;
import com.mie.util.DbUtil;

public class UserDao {
	/**
	 * This class handles all of the Student-related methods
	 * (add/update/delete/get).
	 */

	private Connection connection;

	public UserDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}

	public void addUser(User user) {
		/**
		 * This method adds a new student to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("INSERT INTO Account(Email,FirstName,LastName,Address,City,RegionID,CreditCardNumber,CVC,Expiration,Password) VALUES (?,?,?,?,?,?,?,?,?,?)");
			// Parameters start with 1
			//preparedStatement.setInt(1, user.getAccountId());
			preparedStatement.setString(1, user.getEmail());
			preparedStatement.setString(2, user.getFirstName());
			preparedStatement.setString(3, user.getLastName());
			preparedStatement.setString(4, user.getAddress());
			preparedStatement.setString(5, user.getCity());
			preparedStatement.setInt(6, 1);
			preparedStatement.setString(7, user.getCreditCardNum());
			preparedStatement.setString(8, user.getCVC());
			preparedStatement.setString(9, user.getExpiration());
			preparedStatement.setString(10, user.getPassword());
			preparedStatement.executeUpdate();
			

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteUser(String email) {
		/**
		 * This method deletes a student from the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from Account where Email=?");
			// Parameters start with 1
			preparedStatement.setString(1, email);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateUser(User user) {
		/**
		 * This method updates a users information into the database.
		 */
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("update Account set FirstName=?,LastName=?,Address=?,City=?,RegionID=?,CreditCardNumber=?,CVC=?,Expiration=?,Password=? where Email=?");
					
			// Parameters start with 1
			preparedStatement.setString(1, user.getFirstName());
			preparedStatement.setString(2, user.getLastName());
			preparedStatement.setString(3, user.getAddress());
			preparedStatement.setString(4, user.getCity());
			preparedStatement.setInt(5, 1);
			preparedStatement.setString(6, user.getCreditCardNum());
			preparedStatement.setString(7, user.getCVC());
			preparedStatement.setString(8, user.getExpiration());
			preparedStatement.setString(9, user.getPassword());
			preparedStatement.setString(10, user.getEmail());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	

	public List<User> getAllUsers() {
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
	
		List<User> users = new ArrayList<User>();
		try {
			Statement statement = connection.createStatement();
			// System.out.println("getting students from table");
			ResultSet rs = statement.executeQuery("select * from Account");
			while (rs.next()) {
				User user = new User();
				user.setAccountId(rs.getInt("AccountID"));
				user.setEmail(rs.getString("Email"));
				user.setFirstName(rs.getString("FirstName"));
				user.setLastName(rs.getString("LastName"));
				user.setAddress(rs.getString("Address"));
				user.setCity(rs.getString("City"));
				user.setRegionID(rs.getInt("RegionID"));
				user.setCreditCardNum(rs.getString("CreditCardNumber"));
				user.setCVC(rs.getString("CVC"));
				user.setExpiration(rs.getString("Expiration"));
				user.setPassword(rs.getString("Password"));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}

	public User getUserByEmail(String email) {
		/**
		 * This method retrieves a student by their StudentID number.
		 * 
		 * Currently not used in the sample web app, but code is left here for
		 * your review.
		 */
		User user = new User();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Account where Email=?");
			preparedStatement.setString(1, email);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				//user.setAccountId(rs.getInt("AccountID"));
				user.setEmail(rs.getString("em"));
				user.setFirstName(rs.getString("fn"));
				user.setLastName(rs.getString("ln"));
				user.setAddress(rs.getString("a"));
				user.setCity(rs.getString("c"));
				user.setRegionID(1);
				user.setCreditCardNum(rs.getString("cc"));
				user.setCVC(rs.getString("cvs"));
				user.setExpiration(rs.getString("ex"));
				user.setPassword(rs.getString("pw"));
				
			
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return user;
	}
	


	public List<User> getUserByKeyword(String keyword) {
		/**
		 * This method retrieves a list of students that matches the keyword
		 * entered by the user.
		 */

		List<User> users = new ArrayList<User>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Account where FirstName LIKE ? OR LastName LIKE ? OR Email LIKE ?");

			preparedStatement.setString(1, "%" + keyword + "%");
			preparedStatement.setString(2, "%" + keyword + "%");
			preparedStatement.setString(3, "%" + keyword + "%");
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				User user = new User();
				user.setAccountId(rs.getInt("AccountID"));
				user.setEmail(rs.getString("Email"));
				user.setFirstName(rs.getString("FirstName"));
				user.setLastName(rs.getString("LastName"));
				user.setAddress(rs.getString("Address"));
				user.setCity(rs.getString("City"));
				user.setRegionID(rs.getInt("RegionID"));
				user.setCreditCardNum(rs.getString("CreditCardNumber"));
				user.setCVC(rs.getString("CVC"));
				user.setExpiration(rs.getString("Expiration"));
				user.setPassword(rs.getString("Password"));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}
	
	static Connection currentCon = null;
	static ResultSet rs = null;

	public static User login(User user) {

		/**
		 * This method attempts to find the user that is trying to log in by
		 * first retrieving the email and password entered by the user.
		 */
		Statement stmt = null;

		String email = user.getEmail();
		String password = user.getPassword();

		/**
		 * Prepare a query that searches the Account table in the database
		 * with the given email and password.
		 */
		String searchQuery = "select * from Account where Email='"
				+ email + "' AND Password='" + password + "'";

		try {
			// connect to DB
			currentCon = DbUtil.getConnection();
			stmt = currentCon.createStatement();
			rs = stmt.executeQuery(searchQuery);
			boolean more = rs.next();

			/**
			 * If there are no results from the query, set the member to false.
			 * The person attempting to log in will be redirected to the home
			 * page when isValid is false.
			 */
			
			if (!more) {
				user.setValid(false);
			}

			/**
			 * If the query results in an database entry that matches the
			 * email and password, assign the appropriate information to
			 * the User object.
			 */
			else if (more) {
				String firstName = rs.getString("FirstName");
				String lastName = rs.getString("LastName");

				user.setFirstName(firstName);
				user.setLastName(lastName);
				user.setValid(true);
			}
		}

		catch (Exception ex) {
			System.out.println("Log In failed: An Exception has occurred! "
					+ ex);
		}
		/**
		 * Return the Member object.
		 */
		return user;

	}
}



